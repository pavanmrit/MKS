// Simple scroll animation trigger
document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll('.animate-fade-in, .animate-fade-up');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
      }
    });
  }, { threshold: 0.2 });
  elements.forEach(el => observer.observe(el));
});
